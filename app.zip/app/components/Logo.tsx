"use client";

import { motion } from "framer-motion";

interface LogoProps {
  collapsed?: boolean;
}

export function Logo({ collapsed = false }: LogoProps) {
  return (
    <div className="flex items-center gap-3 px-1 py-2">
      <motion.div
        className="relative flex-shrink-0"
        whileHover={{ scale: 1.05 }}
        transition={{ type: "spring", stiffness: 400, damping: 20 }}
      >
        <div
          className="w-9 h-9 rounded-xl flex items-center justify-center text-[18px] font-bold"
          style={{
            background: "var(--accent-gradient)",
            boxShadow: "0 0 20px rgba(34,211,238,0.35), 0 0 40px rgba(236,72,153,0.25)",
          }}
        >
          🧠
        </div>
        <span
          className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full animate-pulse-glow"
          style={{ background: "#34d399", boxShadow: "0 0 6px #34d399" }}
        />
      </motion.div>

      {!collapsed && (
        <motion.div
          initial={{ opacity: 0, x: -8 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -8 }}
          transition={{ duration: 0.2 }}
          className="flex flex-col leading-tight"
        >
          <span
            className="text-[15px] font-semibold"
            style={{
              background: "var(--nebula-text-gradient)",
              backgroundSize: "300%",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            Shadow Brain
          </span>
          <span
            className="text-[10px] font-medium tracking-widest uppercase"
            style={{ color: "var(--text-muted)" }}
          >
            AI Memory
          </span>
        </motion.div>
      )}
    </div>
  );
}
