"use client";

import { motion } from "framer-motion";
import { Menu, RotateCcw, MoreHorizontal, Network } from "lucide-react";

interface TopBarProps {
  onMenuClick: () => void;
  onClear: () => void;
  onGraphView?: () => void;
}

export function TopBar({ onMenuClick, onClear, onGraphView }: TopBarProps) {
  return (
    <div
      className="flex items-center justify-between px-5 py-3.5 flex-shrink-0"
      style={{
        borderBottom: "1px solid var(--border-subtle)",
        background: "rgba(11,18,32,0.72)",
        backdropFilter: "blur(16px) saturate(140%)",
        WebkitBackdropFilter: "blur(16px) saturate(140%)",
      }}
    >
      <div className="flex items-center gap-3">
        <motion.button
          className="md:hidden p-2 rounded-lg"
          style={{ color: "var(--text-secondary)" }}
          onClick={onMenuClick}
          whileHover={{ background: "var(--bg-hover)", scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Menu size={18} />
        </motion.button>

        <div
          className="flex items-center gap-2 px-3 py-1.5 rounded-full text-[11.5px] font-medium"
          style={{
            background: "rgba(59,130,246,0.1)",
            border: "1px solid var(--border-glow)",
            color: "var(--blue)",
          }}
        >
          <span
            className="w-1.5 h-1.5 rounded-full animate-pulse-glow"
            style={{ background: "#34d399", boxShadow: "0 0 6px #34d399" }}
          />
          Shadow Brain v2.1
        </div>
      </div>

      <div className="flex items-center gap-2">
        {onGraphView && (
          <motion.button
            onClick={onGraphView}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium"
            style={{
              border: "1px solid var(--border-glow)",
              color: "var(--blue)",
              background: "rgba(59,130,246,0.08)",
            }}
            whileHover={{ background: "rgba(59,130,246,0.18)" }}
            whileTap={{ scale: 0.97 }}
          >
            <Network size={12} />
            <span className="hidden sm:inline">Brain Graph</span>
          </motion.button>
        )}

        <motion.button
          onClick={onClear}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium"
          style={{
            border: "1px solid var(--border-subtle)",
            color: "var(--text-secondary)",
          }}
          whileHover={{
            border: "1px solid var(--border-glow)",
            color: "var(--text-primary)",
            background: "var(--bg-hover)",
          }}
          whileTap={{ scale: 0.97 }}
        >
          <RotateCcw size={12} />
          <span className="hidden sm:inline">Clear</span>
        </motion.button>

        <motion.button
          className="p-2 rounded-lg"
          style={{
            border: "1px solid var(--border-subtle)",
            color: "var(--text-secondary)",
          }}
          whileHover={{
            border: "1px solid var(--border-glow)",
            color: "var(--text-primary)",
            background: "var(--bg-hover)",
          }}
          whileTap={{ scale: 0.97 }}
        >
          <MoreHorizontal size={15} />
        </motion.button>
      </div>
    </div>
  );
}
